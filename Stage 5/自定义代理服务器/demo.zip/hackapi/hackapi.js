var express = require('express');
var request = require('request');
var url = require('url');
var app = express();
var fs = require('fs');
var dlog = console.log

//不使用缓存
app.disable('view cache');

//json对象转字符串
function obj2json(obj){
	var jsObj = JSON.parse(obj)
	return  JSON.stringify(jsObj, null, 2);
}

//替换字典中的值
function changeDictWithDict(dict,dict2){
	for (var key in dict2) {
		var ka = key.split('/')
		var d = dict
		if (ka.length == 1) {
			d[key] = dict2[key]
		} else {
			for (var i = 0; i < ka.length; i++) {
				 var tk = ka[i]
				 if (i < ka.length-1) {
				 	d = d[tk]
				 }
				 if (i == ka.length - 1) {
				 	d[tk] = dict2[key]
				 }
			}
		}
	}
}


function sleep(numberMillis) {
	var now = new Date();
	var exitTime = now.getTime() + numberMillis;
	while (true) {
		now = new Date();
		if (now.getTime() > exitTime)
		return;
	    }
}

function pipe(req,host,res){
	var url = host + req.url
	req.pipe(request({url:url,gzip:true},function(error,response,body) {
		if(req.url.indexOf("?") != -1){
    		url = req.url.split("?")[0];
    		dlog('\n'+ url+'\nuse host '+host+'\n')
		}
		dlog('\n'+ obj2json(body)+'\n')
	})).pipe(res);
}

function createAExecute(api,time,host,func){
	var time = arguments[1]? arguments[1] : -1;
	if (time == -1) {
		func()
	} else {
		app.use(api, function(req, res) {
    		if (time == 0) {
    			pipe(req,host+api,res)
    		} 
    		if (time > 0) {
    			time = time - 1;
    			func()
    		}
		});
	}
}






var defaultResendHost = 'http://172.16.0.44/Kid/'

/**
*  api 接口名字
*  filename 返回的json文件，可以是字符串，也可以是数组,如果是数组数据将循环返回
**/
function use(api,filename){
	app.use(api, function(req, res) {
		var fn = filename
		if (filename instanceof Array) {
			fn = filename[0]
		}
		fs.readFile(fn, function (err, data) {
  			if (err) {
      			 return console.error(err);
   			}
   			respStr = data.toString()
   			dlog('\n'+api+'\nuse json\n')
   			dlog('\n'+respStr+'\n')
   			res.send(respStr)
   			if (filename instanceof Array) {
   				filename.push(filename.shift()) //将第一个元素删除并且插入到后面
			}
		});
	});
}

//将api转发给某个服务器
function resend(api,host) {
	var host = arguments[1]?arguments[1]:defaultResendHost
	app.use(api, function(req, res) {
    	pipe(req,host,res)
	});
}



//转发并替换服务器返回的值 kvs是字典或者字典数组，如果是字典数组将循环返回   字典的key为json key的路径，value为想要替换的值
function resendReplace(api,kvs,host) {
	var host = arguments[2]?arguments[2]:defaultResendHost
	app.use(api, function(req, res) {
    	var url = host + api + req.url
    	var kv = kvs
		if (kvs instanceof Array) {
			kv = kvs[0]
		}
    	req.pipe(request({url:url,gzip:true},function(error,response,body) {
			var bodyJson = eval('(' + body + ')')
			dlog('\n'+ api +'\nuse host_replace '+ host + ' ' + JSON.stringify(kv)+'\n')
			dlog('\n' + obj2json(body) + '\n')
			changeDictWithDict(bodyJson,kv)
			res.json(bodyJson)
			if (kvs instanceof Array) {
				kvs.push(kvs.shift()) 
			}
		}))
	});
}

//制造一个超时,time为超时次数，如果不传为-1，表示永远超时
function createAtimeOut(api,time,host){
	var host = arguments[2]?arguments[2]:defaultResendHost
	createAExecute(api,time,host,function(){})
}

//制造一个错误,time为错误，如果不传为-1，表示永远超时
function createAError(api,time,host){
	var host = arguments[2]?arguments[2]:defaultResendHost
	createAExecute(api,time,host,function(){
		throw new Error('create a error')
	})
}

//新用户引导流程
function kid_newUserGuide() {
	use('/Schedule/getMyLessons',['old_user_no_appoint_lesson.json','old_user_na_addt.json','old_user_na_addt_addb.json'])
	use('/Guide/check','new_user_no_show_guide.json')
	resend('/','http://172.16.0.44/Kid/')
}

//老用户引导流程
function kid_oldUserGuide(){
	use('/Guide/check',['old_user_no_show_guide.json','old_user_show_guide.json'])
	use('/Schedule/getMyLessons',['old_user_no_appoint_lesson.json','old_user_have_appoint_lesson.json'])
	resend('/','http://172.16.0.44/Kid/')
}

//老用户适配流程
function kid_oldUserGuideAdjust(){
	//use('/Guide/check',['old_user_no_show_guide.json'])
	//use('/Schedule/getMyLessons',['old_user_no_appoint_lesson.json','old_user_na_addt.json','old_user_na_addt_addb.json'])
	use('/Schedule/getMyLessons','old_user_na_addt.json')

	// var rp1 = {'res/payType':0,"res/status":1}
	// var rp2 = {'res/payType':1,"res/status":1}
	// resendReplace('/Guide/check',
	// 			[rp1,rp2])
	//createAtimeOut('/Schedule/getMyLessons',3)
	use('/Guide/check',['old_user_no_show_guide.json','new_user_no_show_guide.json'])
	//var rp = {'res/isJunior':'1'};
	//resendReplace('/User/getUserInfoSample',rp);
	resend('/')
}


kid_oldUserGuideAdjust()

dlog("start server\n")
app.listen(process.env.PORT || 9999); 