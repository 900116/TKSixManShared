//
//  DadaModel.h
//  ESJsonFormatForMac
//
//  Created by ZX on 2017/6/1.
//  Copyright © 2017年 ZX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataModel : NSObject
@property (readwrite,copy) NSString * key;
@property (readwrite,copy) NSString * value;
@end
