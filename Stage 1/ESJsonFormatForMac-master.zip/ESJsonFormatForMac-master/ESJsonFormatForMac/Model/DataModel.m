//
//  DadaModel.m
//  ESJsonFormatForMac
//
//  Created by ZX on 2017/6/1.
//  Copyright © 2017年 ZX. All rights reserved.
//

#import "DataModel.h"

@implementation DataModel

@end
