//
//  Author.h
//  Demo-YYModel
//
//  Created by 郭彬 on 16/6/20.
//  Copyright © 2016年 walker. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Author : NSObject

@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSData *birthday;

@end
