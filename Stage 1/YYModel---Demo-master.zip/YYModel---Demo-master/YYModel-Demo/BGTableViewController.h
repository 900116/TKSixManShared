//
//  BGTableViewController.h
//  Demo-YYModel
//
//  Created by 郭彬 on 16/6/20.
//  Copyright © 2016年 walker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BGTableViewController : UITableViewController

@end
