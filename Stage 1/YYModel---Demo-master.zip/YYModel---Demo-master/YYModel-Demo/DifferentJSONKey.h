//
//  DifferentJSONKey.h
//  Demo-YYModel
//
//  Created by 郭彬 on 16/6/20.
//  Copyright © 2016年 walker. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YYModel.h"


@interface DifferentJSONKey : NSObject

@property(nonatomic,copy) NSString *UserID;
@property(nonatomic,copy) NSString *createdTime;

@end
