//
//  TimeStampModel.h
//  YYModel-Demo
//
//  Created by 郭彬 on 16/6/27.
//  Copyright © 2016年 walker. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeStampModel : NSObject

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSDate *createdAt;

@end
