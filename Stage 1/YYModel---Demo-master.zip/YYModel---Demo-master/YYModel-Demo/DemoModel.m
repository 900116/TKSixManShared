//
//  DemoModel.m
//  YYModel-Demo
//
//  Created by 郭彬 on 16/6/27.
//  Copyright © 2016年 walker. All rights reserved.
//

#import "DemoModel.h"

@implementation DemoModel

@end
